package cours.exercice_reader;

public interface IfileReader {
    void openFile();
    void closeFile();
}


